import Crawler2


fetcher = Crawler2.ArticleFetcher()
for element in fetcher.fetch():
    print(f"{element.emoji}: {element.title}")